A Pen created at CodePen.io. You can find this one at https://codepen.io/Murkee/pen/ryoJb.

 Social Section

I only little changed hover effect.

Original By Marco Biedermann

http://codepen.io/m412c0/pen/yInjA

http://dribbble.com/shots/1266360-Social-Section-psd